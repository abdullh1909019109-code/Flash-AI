# FLASH AGENT — Android / APK

Two ways to get FLASH AGENT onto an Android phone.

## 1. PWA — no build needed (works today)

The web app already ships everything Android needs to install as an app:

- `public/manifest.webmanifest` (standalone display, brand colours, maskable icon)
- `public/sw.js` (offline shell cache)
- `<link rel="manifest">` + theme colour in `index.html`

Deploy the server over HTTPS, open the site in Chrome on the phone, then
**⋮ → Add to Home screen**. It launches full-screen with its own icon, no browser
chrome, and keeps working when the connection drops.

## 2. Native APK — Capacitor shell

The native project is a thin shell around the deployed web app (exactly how most
production AI apps ship: one codebase, no duplicated UI).

```bash
# on a machine with JDK 17 + Android SDK installed
FLASH_URL=https://your-domain.com bash android/build-apk.sh
# → android/app/build/outputs/apk/debug/app-debug.apk

FLASH_URL=https://your-domain.com bash android/build-apk.sh release
# → signed release APK (needs SIGN_* env vars)
```

Or let CI do it: `.github/workflows/android.yml` builds a debug APK on every push
and a signed release when the four `SIGN_*` secrets are present, uploading the
APK as a workflow artifact.

### Why the APK is not pre-built here

Compiling an APK requires a JDK and the Android SDK (several hundred MB of
tooling plus a Gradle dependency graph). The sandbox this project was generated
in has neither — `java` is not installed — so a real, installable, signed APK
cannot be produced in it. The scaffold above produces one in a single command on
any machine or CI runner that has the toolchain, and the PWA route gives you an
installed app immediately with zero build steps.

### Play Store notes

- `appId` is `app.flashagent.mobile` — change it in `android/capacitor.config.json`
  before publishing (it is permanent once uploaded).
- Bump `versionCode` / `versionName` in `android/app/build.gradle`.
- A microphone permission is required for Flash Voice; Capacitor adds
  `RECORD_AUDIO` automatically when the WebView requests it, otherwise add it to
  `android/app/src/main/AndroidManifest.xml`.
- Store listings require a privacy policy URL because the app sends prompts to
  your backend. Add one before submitting.

